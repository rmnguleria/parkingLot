package com.example.demo.controller;

import com.example.demo.model.ParkingLot;
import com.example.demo.model.ParkingLotLevel;
import com.example.demo.service.ParkingLotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class ParkingLotController {

    @Autowired
    private ParkingLotService parkingLotService;

    @GetMapping("/parkinglot")
    private ParkingLot getParkingLot(@PathVariable( name = "id") Long id)
    {
        return parkingLotService.getParkingLot(id);
    }

    @PostMapping("/parkinglot")
    private ParkingLot saveParkingLot(@RequestBody ParkingLot parkingLot )
    {
        return parkingLotService.createParkingLot(parkingLot);
    }

}
