package com.example.demo.controller;

import com.example.demo.model.Ticket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.service.TicketService;

@RestController
public class TicketController {

    @Autowired
    private TicketService ticketService;

    @GetMapping("/ticket")
    private Ticket getTicket(@PathVariable(name = "id") String uuid) {
        return ticketService.getTicket(uuid);
    }

    @PostMapping("/ticket")
    private Ticket createTicket(@RequestBody Ticket ticket )
    {
        return ticketService.createTicket(ticket);
    }
}
