package com.example.demo.service;

import com.example.demo.config.VehicleType;
import com.example.demo.model.SlotBooking;

public interface SlotBookingService {

    SlotBooking parkVehicle(VehicleType vehicleType, Long parkingLotId, Long entryPointId );
}
