package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.util.Date;

@Getter
@Setter
@Entity
public class Ticket {

    @Id
    private String id;

    @ManyToOne
    @JoinColumn(name = "slot_booking_id")
    private SlotBooking slotBooking;

    @ManyToOne
    @JoinColumn(name = "entry_point_id")
    private EntryPoint entryPoint;

    private String vehicleNumber;

    private String vehicleColour;

    private Date entryTime;
}
