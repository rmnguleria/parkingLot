package com.example.demo.service.impl;

import com.example.demo.model.ParkingLot;
import com.example.demo.model.ParkingLotLevel;
import com.example.demo.model.SlotBooking;
import com.example.demo.repository.ParkingLotLevelRepository;
import com.example.demo.repository.ParkingLotRepository;
import com.example.demo.repository.SlotBookingRepository;
import com.example.demo.service.ParkingLotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ParkingLotServiceImpl implements ParkingLotService {

    @Autowired
    private ParkingLotRepository parkingLotRepository;

    @Autowired
    private SlotBookingRepository slotBookingRepository;

    @Autowired
    private ParkingLotLevelRepository parkingLotLevelRepository;

    @Override
    public ParkingLot createParkingLot(ParkingLot parkingLot) {

        ParkingLot savedLot = parkingLotRepository.save(parkingLot);

        for(ParkingLotLevel level: savedLot.getParkingLotLevels())
        {
            for(int i=0;i<level.getSlots();i++) {
                SlotBooking slotBooking = new SlotBooking();
                slotBooking.setParkingLot(savedLot);
                slotBooking.setParkingLotLevel(level);
                slotBooking.setCount(0);
                slotBookingRepository.save(slotBooking);
            }
        }

        return savedLot;
    }

    @Override
    public ParkingLot getParkingLot(Long id) {
        return parkingLotRepository.getById(id);
    }
}
