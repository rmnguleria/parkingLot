package com.example.demo.service.impl;

import com.example.demo.config.VehicleType;
import com.example.demo.model.EntryPoint;
import com.example.demo.model.ParkingLot;
import com.example.demo.model.ParkingLotLevel;
import com.example.demo.model.SlotBooking;
import com.example.demo.repository.EntryPointRepository;
import com.example.demo.repository.ParkingLotRepository;
import com.example.demo.repository.SlotBookingRepository;
import com.example.demo.service.SlotBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class SlotBookingServiceImpl implements SlotBookingService {

    @Autowired
    private SlotBookingRepository slotBookingRepository;

    @Autowired
    private ParkingLotRepository parkingLotRepository;

    @Autowired
    private EntryPointRepository entryPointRepository;

    private SlotBooking findNearestEmpty(VehicleType vehicleType, Long parkingLotId, Long entryPointId)
    {
        ParkingLot parkingLot = parkingLotRepository.getById(parkingLotId);
        EntryPoint entryPoint = entryPointRepository.getById(entryPointId);
        Set<Integer> levels = parkingLot.getParkingLotLevels().stream()
                .map(ParkingLotLevel::getLevel).collect(Collectors.toSet());
        int entryPointLevel = parkingLot.getParkingLotLevels().stream()
                .filter( level -> level.getEntryPoints().contains(entryPoint)).findFirst().get().getLevel();
        levels.remove(entryPointLevel);

    }

    @Override
    @Transactional
    public SlotBooking parkVehicle(VehicleType vehicleType, Long parkingLotId, Long entryPointId) {
        SlotBooking slot = findNearestEmpty(vehicleType, parkingLotId, entryPointId);
        slot.setCount(slot.getCount() + vehicleType.getSize() );
        return slotBookingRepository.save(slot);
    }
}
