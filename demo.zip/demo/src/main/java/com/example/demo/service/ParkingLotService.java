package com.example.demo.service;

import com.example.demo.model.ParkingLot;

public interface ParkingLotService {

    ParkingLot createParkingLot( ParkingLot parkingLot);

    ParkingLot getParkingLot( Long id );

}
