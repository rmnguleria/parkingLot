package com.example.demo.config;

import lombok.Getter;
import lombok.Setter;

@Getter
public enum VehicleType {

    BIKE(1, 1),
    CAR(2, 2),
    TRUCK(3, 4);

    final int type;
    final int size;

    VehicleType(int type, int size)
    {
        this.type = type;
        this.size = size;
    }


}
