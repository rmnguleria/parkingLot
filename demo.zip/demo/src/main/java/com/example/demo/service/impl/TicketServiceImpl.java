package com.example.demo.service.impl;

import com.example.demo.model.Ticket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.example.demo.repository.TicketRepository;
import com.example.demo.service.TicketService;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

@Component
public class TicketServiceImpl implements TicketService {

    @Autowired
    private TicketRepository ticketRepository;

    @Override
    public Ticket createTicket(Ticket ticket) {
        ticket.setId(UUID.randomUUID().toString());
        ticket.setEntryTime( new Date() );
        return ticketRepository.save(ticket);
    }

    @Override
    public Ticket getTicket(String uuid) {
        Optional<Ticket> byId = ticketRepository.findById(uuid);

        return byId.orElse( null );
    }
}
